# Project description
The code for the RMS for WUC

# to do - Mark's notes
- replace placeholder links with real ones
- decide if to keep existing or add a new favicon
- double check that the alt tags are correctly implemented
- make queries for the website to be usable on mobile
	- hide sidebar when size is small
	- content wrapping
# Dacosta
- index.php requires login page
- splash.php home page
- appointments
=======
- decide if to keep existing or add a new favicon
- make side icons and bottom icons sticky to their appropriate side for better spacing
- double check that the alt tags are correctly implemented
>>>>>>> 9fb66f4c5704acdffb024776c1d06e1de6d2da86

Test