<?php
	$title = 'Privacy Policy'; //sets the title
	$content = '
<div class = "login">
 <img src="image/logo.svg" alt="logo">
	<h1> Privacy Policy </h1>
<p>Asperiores incidunt quaerat sint excepturi et. Dolor atque cumque aut autem assumenda ad rerum nostrum. Consequuntur fuga est exercitationem molestias occaecati. Omnis aut molestias alias delectus voluptatem. Quo odit autem ea. Totam aliquid quia sit officia.</p>
<form action="index.php">
    <input type="submit" class="button" value="Go back" />
</form>
</div>';//sets the content inside the page
require '../templates/login.html.php'; //loads layout.php which contains the layout for the page
?>
